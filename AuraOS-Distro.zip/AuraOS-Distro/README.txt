AuraOS Linux Distribution Project for Windows

To build the ISO:
1. Upload this folder to GitHub
2. Run the GitHub Actions workflow in .github/workflows/build-iso.yml
Or run build-scripts/build-in-wsl.sh inside WSL2 in Windows.
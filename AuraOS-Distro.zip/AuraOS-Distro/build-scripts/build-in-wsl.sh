#!/bin/bash
set -e
echo "=== [WSL2] Сборка загрузочного ISO-образа AuraOS ==="
sudo apt-get update && sudo apt-get install -y arch-install-scripts xorriso squashfs-tools dosfstools mtools git
sudo pacman-key --init || true
sudo mkarchiso -v -w /tmp/aura-work -o ./out ./iso-profile
echo "=== Сборка завершена успешно! Ищите ISO в папке out/ ==="